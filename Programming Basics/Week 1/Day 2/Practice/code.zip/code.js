// this is number variable
var likeCount = 0;
// YOUR COMMENT HERE - what would be the function of this code block?
function increaseLikes() {
    // YOUR COMMENT HERE - what is this sort operation for?
    likeCount = likeCount + 1;
}
